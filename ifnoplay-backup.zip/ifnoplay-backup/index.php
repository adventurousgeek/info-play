<?php require_once __DIR__ . '/common-components/header.php'; ?>
<main class="site-main">
    <canvas id="background-canvas"></canvas>
    <?php require_once __DIR__ . '/components/home.php'; ?>

    <canvas id="sphere"></canvas>
</main>
<?php require_once __DIR__ . '/common-components/footer.php'; ?>



	
	
